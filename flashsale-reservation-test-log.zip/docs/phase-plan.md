# Build plan

Flash-sale / ticket reservation system: an event-driven backend built to
learn distributed systems, Kafka, Go, and AI service integration end to end.

Full architecture and requirements discussion lives in the design
conversation this repo came out of -- this doc tracks the concrete,
checkable path through it.

- [x] **Phase 1 -- Architecture & requirements**
      Requirements drafted (throughput, latency, delivery guarantee,
      consistency model, fairness rule, reservation TTL). Repo scaffolded.
- [x] **Phase 2 -- Go fundamentals**
      Waiting-room admission logic: goroutines, channels, context,
      graceful shutdown. Built as real code for this project, not toy
      examples.
- [x] **Phase 3 -- Postgres & data model**
      Schema for items, reservations, orders. Migrations.
- [x] **Phase 4 -- Go API service**
      waiting-room-api + checkout-api over HTTP. Redis-only fast path,
      no Kafka yet. Buyers join a per-item FIFO queue in
      waiting-room-api (Phase 2's Admitter, now with one instance per
      item ID); admission grants a short-lived Redis token that
      checkout-api requires before it'll atomically decrement the
      item's fast-path inventory counter. No durable reservation is
      created yet -- that's Phase 6, once Kafka + decision-service +
      Postgres are wired together.
- [x] **Phase 5 -- Kafka fundamentals**
      Manually produce/consume messages via the CLI and Kafka UI. Build
      intuition for topics, partitions, offsets, consumer groups before
      writing a line of Go against them.
- [x] **Phase 6 -- Producers/consumers**
      Real Kafka producer in checkout-api (partitioned by item ID). Real
      consumer in decision-service. This is where overselling gets
      prevented for real. Core correctness logic
      (`internal/decision.ProcessAttempt`) verified directly against
      Postgres, including a 50-goroutine concurrency test against 10
      units of stock. Kafka wire-level behavior (partition routing,
      consumer group rebalancing, end-to-end buyer flow) verified on
      the actual dev machine -- see `docs/phase6.md`.
- [x] **Phase 7 -- Worker architecture**
      expiry-worker as a proper worker-pool pattern: one scanner
      goroutine on a ticker, a fixed pool of worker goroutines draining
      a shared job channel. Correctness logic
      (`internal/expiry.ExpireReservation`) verified against real
      Postgres, including a 50-goroutine concurrency test proving a
      reservation's inventory is never released twice. Verified end to
      end by seeding a realistic mix of expired/not-yet-expired/
      already-completed reservations and running the actual compiled
      binary against them -- see `docs/phase7.md`.
- [x] **Phase 8 -- Reliability & failure handling**
      Idempotency, retries, dead-letter topic. Then deliberately break
      things (kill a consumer mid-batch, stop Postgres, duplicate an
      event) and confirm the system recovers the way it's supposed to.
      Idempotency was already built (Phase 6/7); this phase closed a
      real gap in the existing retry policy -- an extended Postgres
      outage would have dead-lettered every in-flight message, not just
      genuinely bad ones. `classifyOutcome` distinguishes infra failures
      (retry forever, uncounted) from data failures (dead-letter
      promptly) from unknown Postgres errors (bounded by the existing
      `retry.Policy`). The classification logic itself is unit-tested
      (8 tests, no broker needed); the actual chaos-testing exercises
      (kill mid-batch, stop Postgres, duplicate an event) still need to
      be run against the real stack -- not yet done by anyone. See
      `docs/phase8.md`.
- [x] **Phase 9 -- Redis**
      internal/reconcile replaces Phase 4's dev-only manual seed
      endpoint with the real thing: on startup, and then every
      `INVENTORY_RECONCILE_INTERVAL_SECONDS`, checkout-api reads every
      on-sale/scheduled item's authoritative `available_inventory` from
      Postgres and overwrites Redis's fast-path copy to match --
      Postgres always wins, no merge logic. A new
      `POST /items/{id}/reconcile` endpoint does the same thing
      on-demand for one item. Waiting-room queue state: the in-memory
      Admitter (Phase 2) gained a non-blocking `Depth` query, and
      waiting-room-api's new `GET /items/{id}/queue` endpoint publishes
      that number into Redis (`redisx.SetQueueDepth`) so it's visible
      without a caller needing its own Admitter -- the Admitter stays
      the actual source of truth, Redis just caches a number read from
      it. Risk-score cache: `redisx.SetRiskScore`/`GetRiskScore` build
      the write/read surface Phase 10's risk-service needs; nothing
      calls it yet. All new logic verified directly against real
      Postgres and Redis. See `docs/phase9.md`.
- [x] **Phase 10 -- FastAPI AI service**
      risk-service consumes waiting-room events, scores bot/scalper
      risk asynchronously, writes to Redis. This phase's own gap
      surfaced immediately: "waiting-room events" didn't exist yet --
      waiting-room-api had never published anything to Kafka. Added
      that first: a `BuyerJoined` event (`internal/kafkax`) published
      from a background goroutine after a buyer is actually admitted,
      never on the request path, so a slow/unreachable Kafka broker
      can't add latency to admission (verified directly: admission
      still returns in ~0.1s with the broker pointed at a closed
      port). risk-service (Python/FastAPI) consumes that topic, tracks
      two sliding-window signals per event in Redis (join velocity per
      user, distinct users per IP) via `risk_window.py`, and combines
      them into a score via `scoring.py` -- a documented heuristic, not
      a trained model, since there's no labeled data in this project
      to train one on. Scores land in the same `risk:{item}:{user}`
      Redis key Phase 9 defined, wire-compatible in both directions
      (verified with a real Go-marshaled event parsed and processed by
      the Python side end to end). Nothing consumes a score to change
      a decision yet -- per the Phase 1 design decision, that would
      require calling into this from checkout-api's hot path, which
      is explicitly out of bounds. See `docs/phase10.md`.
- [ ] **Phase 11 -- Observability**
      Structured logs, Prometheus metrics, Grafana dashboards,
      OpenTelemetry traces, correlation IDs across every service.
- [ ] **Phase 12 -- Docker & deployment**
      Full docker-compose stack for all services (not just infra),
      health checks, graceful shutdown verified under `docker stop`.
- [ ] **Phase 13 -- Load testing & benchmarking**
      Simulate a burst of ~2,000 concurrent buyers against ~200 tickets.
      Measure checkout p99 latency and Kafka consumer lag under load.
- [ ] **Phase 14 -- System design / interview prep**
      Write up the design as a story: what problem it solves, the key
      tradeoffs (sync fast path vs. async authoritative path,
      partition-key choice, idempotency strategy), and what broke during
      testing and how it was fixed.

## Key design decisions locked in during Phase 1

- **Delivery guarantee:** at-least-once. All consumers must be idempotent
  by design -- not retrofitted later.
- **Source of truth:** Postgres. Redis is fast, disposable, derived state
  -- rebuildable from Postgres if lost.
- **Partition key:** item ID. Guarantees one ordered stream of purchase
  attempts per item, so exactly one consumer instance ever decides that
  item's outcome at a time.
- **AI placement:** the risk model runs asynchronously and writes to
  Redis. It is never called synchronously in the checkout hot path --
  that would trade fairness/latency for a marginal risk-scoring benefit.
- **Reservation TTL:** unpaid reservations expire and release inventory
  automatically (compensating-transaction pattern), rather than locking
  stock indefinitely.
